-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2022 at 01:27 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nur`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`) VALUES
(3, 'International'),
(4, 'Politics'),
(7, 'Sports'),
(8, 'Monthly'),
(9, 'Yesterday'),
(10, 'Today');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`id`, `note`) VALUES
(1, 'Daily news');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `body`) VALUES
(1, 'About Us', '<p><span>4 November 1998. With the very first light of dawn, Prothom Alo (The First Light), started its humble journey. Because of its courageous journalism, rich content, and presentation with unique layout and design, Prothom Alo quickly won the hearts of people, even the most sophisticated and fastidious readers extended their loyalty toward it. Since then, Prothom Alo has been lighting up every nook and corner of Bangladesh along with 200 other countries and territories across the world through its print and digital offerings.</span></p>'),
(2, 'Privacy Policy', '<p dir=\"ltr\"><span>4 November 1998. With the very first light of dawn, Prothom Alo (The First Light), started its humble journey. Because of its courageous journalism, rich content, and presentation with unique layout and design, Prothom Alo quickly won the hearts of people, even the most sophisticated and fastidious readers extended their loyalty toward it. Since then, Prothom Alo has been lighting up every nook and corner of Bangladesh along with 200 other countries and territories across the world through its print and digital offerings.</span></p>'),
(3, 'Terms Of Use', '<p>These Terms of Use (\"<strong><em>Terms</em></strong>\") apply to your access to, and use of, this website&nbsp;or othe<span>4 November 1998. With the very first light of dawn, Prothom Alo (The First Light), started its humble journey. Because of its courageous journalism, rich content, and presentation with unique layout and design, Prothom Alo quickly won the hearts of people, even the most sophisticated and fastidious readers extended their loyalty toward it. Since then, Prothom Alo has been lighting up every nook and corner of Bangladesh along with 200 other countries and territories across the world through its print and digital offerings.</span></p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat`, `title`, `body`, `image`, `author`, `tags`, `date`, `userid`) VALUES
(17, 3, 'Apex court hamstrung by a judge crisis', '<p>In Bangladesh, bureaucracy seems to thrive on misplaced priorities. A classic example is when undeserved and unnecessary promotions to secretary-level posts are readily approved by the public administration, but essential appointments &ndash; of doctors and judges, for example &ndash; that have a direct bearing on the wellbeing of citizens are put on the back burner. A continuation of this culture has been reported at the Appellate Division of the Supreme Court, which is facing a shortage of judges. Currently, there are only five judges, including the chief justice, who are having to deal with upwards of 17,500 cases. That\'s 3,500 cases per head. Let that sink in. We cannot help but wonder: Why would there be a judge crisis at the highest court of the country? The law minister, when approached for comments, had no answer to that beyond the standard appointing-judges-is-a-continuous-process response. One would expect a more direct, affirmative response. This crisis, which will only delay justice and thus increase suffering, comes against a backdrop of an already huge backlog of cases across the Supreme Court. At the High Court Division, there are 95 judges in charge of clearing a whopping 5.18 lakh pending cases. Expecting so few judges to dispense so many cases is simply absurd.</p>', 'upload/a595255f3a.png', 'Nur', 'News', '2021-11-30 15:12:58', 1),
(19, 4, 'No more dirty tactics before election', '<p>just like in Khulna, Mymensingh, and Barishal, transport owners in Rangpur called a 36-hour strike from October 28, a day before the BNP rally. Mozammel Haq, president of the Rangpur Motor Malik Samity which called the strike, is an adviser of AL\'s Rangpur City unit while Mashiur Rahman Ranga, general secretary of the body, is a Jatiya Party lawmaker from Rangpur. Similarly, in a report this newspaper published on Friday, it revealed that the strikes called in Khulna, Mymensingh and Barishal were all called by associations either directly controlled by local AL leaders or their loyalists. And there is no reason to doubt that this instruction was not passed onto them from high ranking party members &ndash; especially given how well-coordinated it has been. It is extremely disturbing just how much transport associations, similar to all other associations in various sectors, have been completely politicised by the AL and used for its narrow political purposes. Even in this case, let us not forget that ordinary citizens have also been suffering as a result of the lack of private transport. The transport sector, in general, has been a mess as a result of this deep politicisation, which has been leading to deaths from road accidents on a regular basis &ndash; and no meaningful reforms have been taken to fix the sector because of political reasons, despite the heavy cost to citizens.</p>', 'upload/520a1c123a.png', 'Faysal', 'Today', '2021-11-30 15:32:52', 1),
(20, 7, 'On the verge of starvation', '<p>A World Bank survey conducted between June 2020 and May 2022 has found that around 30 percent people in Bangladesh are currently facing food scarcity. This is despite the fact that the country\'s economy made a recovery from pandemic-induced shocks, according to the report. The survey has found that 13 percent of people went to sleep hungry in May this year, compared to seven percent in June 2021. During the same time, the number of people who could not afford to buy food and those who didn\'t eat in 24 hours also increased. These findings have been revealed at a time when we are already worried about the rising inflation that has affected purchasing capacities and the food shortage that the country might face in the coming months.</p>', 'upload/a58232ddd1.png', 'Anis', 'Blog', '2021-11-30 15:38:00', 1),
(27, 10, 'Take stern action to stop drug trade', '<p>While our law enforcement agencies have been intensifying their drives to break the network of yaba traders along Myanmar-Bangladesh borders, their efforts seem to be falling behind, as drug dealers are adopting novel methods of smuggling yaba from Myanmar to Bangladesh. According to a report by this daily, national and transnational syndicates are now using local \"drug mules\" &ndash; also known as \"fighters\" &ndash; who have trained themselves in such a way that they can avert the scrutiny of law enforcers while working as informers of the smugglers. According to the law enforcers, these \"fighters\" have trained themselves to hold their breath for a long time, hide underneath riverside mud for hours, motionless, or to stay seated on a tree the whole night &ndash; techniques that have made them competent agents of the drug traders. They usually go to the Naf River with fishing rods to keep an eye on law enforcers\' movement, and whenever they notice any lax monitoring by law enforcers or gaps during changes in duty, they send signals to the smugglers. Smugglers from the Myanmar side then enter Bangladesh\'s territory via small, speedy boats, and deliver the consignments to them and return.</p>', 'upload/821ff59edc.png', 'Nur', 'News Today', '2021-11-30 16:24:11', 1),
(28, 8, 'No visible gain from Hasina’s India visit', '<p>The BNP yesterday said Bangladesh made no \"visible achievement\" from Prime Minister Sheikh Hasina\'s four-day tour of India. \"Till now, the achievement is the Kushiyara river water sharing deal. Apart from this, we have not seen any visible achievement,\" said BNP Secretary General Mirza Fakhrul Islam Alamgir. He was speaking to reporters after paying homage to party founder Ziaur Rahman by placing a wreath at his grave in the capital\'s Sher-e-Bangla Nagar, marking the 44th founding anniversary of Jatiyatabadi Mohila Dal. Stating that a $500 million defence contract was signed to buy vehicles from India, the BNP leader said an assurance was made that border killings would be brought down to zero. \"The very day it was said, one person was killed at the Dinajpur border and two others went missing. This is the outcome [of the prime minister\'s visit].\" Fakhrul said though there was no fruitful outcome of the visit, the ruling Awami League leaders in their statements are expressing their \"love\" for India. \"The government has become desperate [to stay in power]. You must remember that before this visit the foreign minister [AK Abdul Momen] had said that he requested Indian leaders to take measures to keep the Awami League government in power by any means,\" he said. The BNP secretary general said his party believed that all democratic countries would play their role in upholding democracy and establishing people\'s rights around the world. \"India is our good friend and a democratic country. We believe that India will also keep its democratic character intact,\" he said.</p>', 'upload/34b4dce262.jpg', 'Nur', 'Politics', '2022-10-31 11:28:43', 1),
(29, 9, 'On the verge of starvation', '<p>A World Bank survey conducted between June 2020 and May 2022 has found that around 30 percent people in Bangladesh are currently facing food scarcity. This is despite the fact that the country\'s economy made a recovery from pandemic-induced shocks, according to the report. The survey has found that 13 percent of people went to sleep hungry in May this year, compared to seven percent in June 2021. During the same time, the number of people who could not afford to buy food and those who didn\'t eat in 24 hours also increased. These findings have been revealed at a time when we are already worried about the rising inflation that has affected purchasing capacities and the food shortage that the country might face in the coming months.</p>', 'upload/1e4feef640.png', 'Nur', 'blog', '2022-10-31 11:33:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `image`) VALUES
(1, 'True news', 'upload/slider/01d103ce7e.jpg'),
(2, 'Daily News', 'upload/slider/6b9f210a9d.jpg'),
(4, 'International News', 'upload/slider/13424f6de5.jpg'),
(5, 'All News', 'upload/slider/8bdbdca39a.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tw` varchar(255) NOT NULL,
  `ln` varchar(255) NOT NULL,
  `gp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `fb`, `tw`, `ln`, `gp`) VALUES
(1, 'http://facebook.com', 'http://twitter.com', 'http://linkedin.com', 'http://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_theme`
--

CREATE TABLE `tbl_theme` (
  `id` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_theme`
--

INSERT INTO `tbl_theme` (`id`, `theme`) VALUES
(1, 'green');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `details`, `role`) VALUES
(1, 'Nur Mohammad Showrab', 'Nur', '202cb962ac59075b964b07152d234b70', 'nur.cse6.bu@gmail.com', '<p>Nur Mohammad Showrab. He is a student of CSE at the University of Barishal.</p>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `slogan`, `logo`) VALUES
(1, 'Daily news', 'All kind of news here', 'upload/logo.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
